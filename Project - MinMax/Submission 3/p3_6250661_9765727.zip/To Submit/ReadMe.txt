We certify that this submission is the original work of members of the group and meets the faculty's expectation of originality.
Peter El-Jiz 6250661
Kevin El-Hage 9765727