//
//  MMTree.java
//  MMTree
//
//  Created by Peter El Jiz & Kevin El-Hage on 2012-10-19.
//  Copyright (c) 2012 Peter El Jiz & Kevin El-Hage. All rights reserved.
//

//import java.util.Iterator;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
//import java.util.ArrayList;

public class MMTree
{

    private int value;
    private boolean isMax;
    private boolean isMin;
    private boolean assigned;
    private MMTree parent;
    private List<MMTree> children;
    private int best_child;
    private MMTree next;
    //ArrayStack s = new ArrayStack(200);
    ArrayQueue q = new ArrayQueue(100);


    //keep some form of memory that stores all the children...for each button, there's a grid
    //private int[][] childmoves = new int[9][8]; //index to the child corresponding to that move

    //Current MagneticCave
    private MagneticCave currentState;
    private ArrayList<MMTree> lastLevel; //lookahead level;
    private boolean blackTurn = true;
    private Position move;


    private boolean first = true;
    

    public MMTree()
    {
        if (parent == null)
        {
            isMax = true;
            //this.value = 9999;
        }


        this.value = value;
        children = new LinkedList<MMTree>();

        lastLevel = new ArrayList<MMTree>();

        assigned = false;

        //MagneticCave
        currentState = new MagneticCave();
        move = new Position(0, 0);

    }
    

    public MMTree(int value)
    {

        this.value = value;
        children = new LinkedList<MMTree>();
        assigned = true;

        lastLevel = new ArrayList<MMTree>();

        
        //MagneticCave
        currentState = new MagneticCave();
        move = new Position(0, 0);
    }


    public void addChild(MMTree ch)
    {
        if (this.isMax == true)
        {
            ch.isMax = false;
            //if (ch.value == 0)
            //ch.value = 9999;
        }
        else
        {
            ch.isMax = true;
            //if (ch.value == 0)
            //ch.value = -9999;
        }

        children.add(ch);
        ch.parent = this;

        ch.first = false;


    }


    public void pruneTree(MMTree ch)
    {
        children.remove(ch);
        ch.parent = null;

        //deleteTree(ch);
    }

    public static void pruneChildren(MMTree ch)
    {
        ListIterator itr = ch.children.listIterator();
        itr.next();

        while (itr.hasNext())
        {
            ((MMTree) itr.next()).parent = null;
            itr.remove();
        }


        //deleteTree(ch);
    }

    public void deleteTree(MMTree ch)
    {
        /*
        ch.children
        deleteTree(ch.);
         */
    }

    public boolean isMax()
    {
        return isMax;
    }

    public boolean isLeaf()
    {
        return children.isEmpty();
    }

    public MMTree getParent()
    {
        return parent;
    }

    public static void preOrder(MMTree t)
    {
    }

    public static void minimax(MMTree c)
    {
        ListIterator itr = c.children.listIterator();



        if (!(c.isLeaf()))
        {
            while (itr.hasNext())
            {
                minimax((MMTree) itr.next());
            }
            
        }



        if (c.parent != null)
        {


            int father = c.parent.value;
            int son = c.value;

            boolean parentMax = c.parent.isMax;




            if (c.parent.assigned == false)
            {
                c.parent.value = c.value;
                c.parent.assigned = true;
            }

            if (parentMax == true)
            {

                if (father < son)
                {
                    c.parent.value = son;
                }

            }
            else
            {
                if (father > son)
                {

                    c.parent.value = son;

                }

            }

        }

    }


    public static void minimaxForLevel(MMTree root, MMTree c, int level, int maxLevel) //returns the index of the bestchild
    {

        ListIterator itr = c.children.listIterator();

        if (level < maxLevel)
        {
            //System.out.println("HERE");
            while (itr.hasNext())
            {
                minimaxForLevel(root, ((MMTree) itr.next()), level + 1, maxLevel);
            }
            
        }



        if (c.parent != null)
        {
            int father = c.parent.value;
            int son = c.value;

            boolean parentMax = c.parent.isMax;



            if (c.parent.assigned == false)
            {
                c.parent.value = c.value;
                c.parent.assigned = true;
            }

            if (parentMax == true)
            {
                if (father < son)
                {
                    c.parent.value = son;
                }

            }
            else
            {
                if (father > son)
                {
                    c.parent.value = son;

                }

            }

        }

    }



















































    public static void pruneSiblings(MMTree ch)
    {
        if (ch.parent != null)
        {
            MMTree parent = ch.parent;
            MMTree self = ch;


            ListIterator itr = ch.parent.children.listIterator();
            itr.next();

            while (itr.hasNext())
            {
                ((MMTree) itr.next()).parent = null;
                itr.remove();
            }

            //ch.parent = parent;
            //ch.parent.children.add(ch);


            //ch.parent.children = new LinkedList<MMTree>();
            //ch.parent.children.add(ch);

            //deleteTree(ch);



        }

    }

    public static void alphabetaForLevel(MMTree root, MMTree c, int level, int maxLevel) //returns the index of the bestchild
    {

        ListIterator itr = c.children.listIterator();

        if (level < maxLevel)
        {
            //System.out.println("HERE");
            while (itr.hasNext()) {
                alphabetaForLevel(root, ((MMTree) itr.next()), level + 1, maxLevel);
            }
        }



        if (c.parent != null)
        {
            int father = c.parent.value;
            int son = c.value;

            boolean parentMax = c.parent.isMax;



            if (c.parent.assigned == false)
            {
                c.parent.value = c.value;
                c.parent.assigned = true;
            }

            //pruning decision

            if (parentMax == true)
            {
                if (father < son)
                {
                    c.parent.value = son;
                }

            }
            else
            {
                if (father > son)
                {
                    c.parent.value = son;
                }
                
            }

        }
        
        
        //pruning decision, check my parent and grandparent and compare
        if (c.parent != null)
            if (c.parent.parent != null)
                if (c.parent.parent.assigned == true)
                {
                    if (!(c.parent.parent.isMax))
                    {
                        if (c.parent.parent.value <= c.parent.value) //<= or < ?
                        {
                            pruneSiblings(c);//prune other chilren of c.parent
                            //System.gc();
                        }

                    }
                    else
                    {
                        if (c.parent.parent.value >= c.parent.value) //>= or > ?
                        {
                            pruneSiblings(c);//prune other children of c.parent
                            //System.gc();
                        }
                    }

                }

    }

















































    public static void alphabeta(MMTree c) //this method still doesn't work yet...I'm in the process of writing it
    {
        ListIterator itr = c.children.listIterator();


        if (!(c.isLeaf())) {
            alphabeta((MMTree) itr.next());
        }


        /*
        //parent code
        if (c.parent != null)
        {
        if (c.parent.isMax())
        {
        if (c.parent.value > c.value) //parent akbar minne w parent maximum
        {
        pruneChildren(c);
        }
        }
        else
        {//iza parent minimum
        if (c.parent.value < c.value) //parent azghar minne w parent minimum
        {
        pruneChildren(c);
        }
        }

        }
         */

        if (!(c.isLeaf())) {
            while (itr.hasNext()) {
                alphabeta((MMTree) itr.next());
            }

        }

        if (c.parent != null) {
            int father = c.parent.value;
            int son = c.value;

            boolean parentMax = c.parent.isMax;

            if (c.parent.assigned == false) {
                c.parent.value = c.value;
                c.parent.assigned = true;
            }

            if (parentMax == true) {
                if (father < son) {
                    c.parent.value = son;
                }
            } else {
                if (father > son) {
                    c.parent.value = son;
                }

            }
        }

    }

    public void levelOrderPrint() {
        if (this.parent == null) {
            System.out.println("Level Order:");
        }


        q.put(this);

        while (!(q.isEmpty())) {
            MMTree c = (MMTree) q.remove();
            System.out.print(c.value + " ");

            ListIterator itr = c.children.listIterator();

            while (itr.hasNext()) {
                q.put((MMTree) itr.next());
            }

        }

    }

    public static void preOrderPrint(MMTree c) {
        if (c.parent == null) {
            System.out.println("Pre Order:");
        }

        System.out.print(c.value + " ");

        ListIterator itr = c.children.listIterator();


        if (!(c.isLeaf())) {
            while (itr.hasNext()) {
                preOrderPrint((MMTree) itr.next());
            }
        }


    }

    public static void postOrderPrint(MMTree c) {
        if (c.parent == null) {
            System.out.println("Post Order:");
        }

        ListIterator itr = c.children.listIterator();


        if (!(c.isLeaf())) {
            while (itr.hasNext()) {
                postOrderPrint((MMTree) itr.next());
            }
        }


        System.out.print(c.value + " ");


    }

    public static MMTree generateRandomNumbersTree()
    {
        MMTree randomTree = new MMTree();

        randomTree.addChild(new MMTree());
        randomTree.addChild(new MMTree());
        randomTree.addChild(new MMTree());
        randomTree.addChild(new MMTree());

        randomTree.children.get(0).addChild(new MMTree((int) (Math.random() * 17)));
        randomTree.children.get(0).addChild(new MMTree((int) (Math.random() * 17)));

        randomTree.children.get(1).addChild(new MMTree((int) (Math.random() * 17)));
        randomTree.children.get(1).addChild(new MMTree((int) (Math.random() * 17)));

        randomTree.children.get(2).addChild(new MMTree((int) (Math.random() * 17)));
        randomTree.children.get(2).addChild(new MMTree((int) (Math.random() * 17)));

        randomTree.children.get(3).addChild(new MMTree((int) (Math.random() * 17)));
        randomTree.children.get(3).addChild(new MMTree((int) (Math.random() * 17)));




        return randomTree;
    }

    public boolean hasNext()
    {
        return next != null;
    }



    public static void swap(MMTree a, MMTree b) //replaces a with b, and deletes b
    {

        //if (a.first == true)
            //b.currentState.setblackturn(true);

        //boolean temp = a.first;
        //boolean temp = a.currentState.getblackturn();
        a.children = null;
        a.currentState = null;
        a.lastLevel = null;
        a.next = null;
        a.parent = null;
        a.move = null;
        //a = null;
        //System.gc();

        a.assigned = b.assigned;
        a.best_child = b.best_child;
        a.value = b.value;

        if (a.blackTurn == true)
            a.blackTurn = false;
        else
            a.blackTurn = true;
        
        //a.blackTurn = b.blackTurn;
        //a.childmoves = b.childmoves;
        a.children = b.children;
        a.currentState = b.currentState;
        //a.currentState.setblackturn(temp);
        a.isMax = b.isMax;
        a.isMin = b.isMin;
        a.lastLevel = b.lastLevel;
        a.next = b.next;
        a.parent = b.parent;
        a.move = b.move;

        //b.childmoves = null;
        b.children = null;
        b.currentState = null;
        b.lastLevel = null;
        b.next = null;
        b.parent = null;
        b.move = null;
        b = null;
        //System.gc();

        //a.first = temp;

    }

    public void addMove(int row, char column) throws Exception
    {

        if ( (column >= 'a') && (column <= 'z'))
        {
            column = (char) (((int) column) - 32);
        }


        if ((row < 1) || (row > 8) || (column < 'A') || (column > 'H'))
            throw new Exception();


        int trueColumn = column - 65;
        int trueRow = row;

        //this.first = false;
        
        if(this.children.isEmpty())
        {
                //this.first = true;
                this.currentState.addToGrid(trueRow, trueColumn);

                //get possible moves //possiblemoves mawjoudin bil list
                //create children and add the possible moves.
                //delete new position from children
                //this.lookAheadTill(this, this, 0, 2);
                lookAheadTill(this, this, 0, 0);

            

        }
        else
        {
            
            Position toFind = new Position(trueRow, trueColumn);
            Position value;
            int index = 0;

            ListIterator selector = this.children.listIterator();

                while (selector.hasNext())
                {
                    value = ((MMTree) selector.next()).move;
                    
                    if (value.equals(toFind))
                        break;
                    index++;
                }
            
            //System.out.println("INDEX: " + index);

            MMTree child = this.children.get(index);

            //System.out.println("\n\n\n\nChild:\n" + child.currentState + "\n\n\n");

            swap(this, child);

            //System.out.println("HERE");

            this.parent = null;
            //System.gc();
            //choose the corresponding child from double array
            //choose that child
            //add possiblemoves to children
            //severe ties with parent
            //change the grid to reflect the new children

        }
    }

    public static void lookAheadTill(MMTree root, MMTree c, int level, int maxLevel)
    {
        /*
        if (level == 0)
        {
            ListIterator deleter = c.children.listIterator();
            while (deleter.hasNext())
            {
                (deleter.next())
            }

            System.gc();
        }
         */




        //We clear the lastLevel list, because it will change at the end of the lookahead method
        //WE assume that if there are children, the lookahead was previously computed for that level,
        //and we just do the children of the children
        //when doing children of children, we assign to false for each node, (except the last level)
        //we assign the last level to true, to be able to do minimax
        //we may also assign a heuristic value here in the lookahead code
        //lastlevel ===> gets assigned a heuristic value, gets the boolean value assigned changed to true
        //minimax is performed

        if (level == 0) //ya3ne root
        {
            root.assigned = false;
            root.value = 0;
            root.lastLevel.clear();
        }

        if (level == maxLevel)
        {
            //System.out.println("Last Level");
            if (c != root)
            {
                root.lastLevel.add(c);
                c.assigned = true;
            }
        }

        if ((c.children.isEmpty()))
        {
            //System.out.println("Level: " + level);
            ListIterator itr = c.currentState.getpossibleMoves().listIterator();
            //int i = 0;

            while (itr.hasNext())
            {
                MMTree newTree = new MMTree();
                newTree.currentState = new MagneticCave(c.currentState); //copy instead of assigning

                Position p = (Position) itr.next();
                int row = p.row;
                int col = p.col;

                //System.out.println("\nRow: " + row + "\nCol: " + col);

                //itr.remove();

                //if (c.currentState.blackturn == true)
                //if (c.first)
                    //c.currentState.setblackturn(false);
                
                if ((c.currentState.getblackturn() == true))
                {
                    newTree.currentState.setblackturn(true);
                }
                else
                {
                    newTree.currentState.setblackturn(false);
                }

                //if ((c == root) && (root.first))
                    //newTree.currentState.setblackturn(false);




                try
                {
                    //System.out.println("New Tree Turn: " + newTree.currentState.getblackturn());
                    newTree.currentState.addToGrid(row, col); //tabbe2 3le l move
                    newTree.currentState.getpossibleMoves().remove(p);

                    //System.out.println("HERE");
                    //root.started = true;
                    //c.childmoves[row][col] = i;
                    newTree.move = p;
                    
                    c.addChild(newTree);
                    //i++;
                }
                catch (Exception ex)
                {
                    System.err.println("Could not add to Grid:\nRow: " + row + "\nCol: " + col);
                }


                //System.out.println("\n\n\nRow: " + row + "\nCol: " + col);

                //System.out.println("\nOLD OBJECT: \n" + c.currentState);
                //System.out.println("\nNEW OBJECT: \n" + newTree.currentState);


            }
        }
        else
        {
            
            ListIterator reseter = c.children.listIterator();
            while(reseter.hasNext())
            {
                MMTree current = ((MMTree) reseter.next());
                current.assigned = false;
                current.value = 0;
            }
            
        }

            if ((level != maxLevel) && (level < maxLevel))
            {
                ListIterator itr2 = c.children.listIterator();

                while (itr2.hasNext())
                {
                    lookAheadTill(root, ((MMTree) itr2.next()), level + 1, maxLevel);
                }

            }

    }

    public static int computeHeuristic(MMTree node)
    {
        int blackValue = 0;
        int whiteValue = 0;

        for (int i = 8; i > 0; i--)
        {
            for (int j = 0; j < 8; j++)
            {
                if (node.currentState.getGridValueAt(i, j) == 1)
                {
                     if (node.currentState.checkValue(i, j) > blackValue)
                     {
                         blackValue = node.currentState.checkValue(i, j);
                         //System.out.println("BlackValue: " + blackValue);

                     }
                }
                else
                    if (node.currentState.getGridValueAt(i, j) == 2)
                    {
                        if (node.currentState.checkValue(i, j) > whiteValue)
                            whiteValue = node.currentState.checkValue(i, j);
                    }
            }
        }

        int heuristic = 0;

        if(blackValue >= 5)
            heuristic = blackValue;
        else
            if(whiteValue >= 5)
                heuristic = -whiteValue;
            else
                heuristic = blackValue - whiteValue; //(max - min)


        //compute heuristic, give original node, and give child node, iza l highest blackwin azghar bil child, laken kheda
        //for black, iza l win bil child a7san kheda...
        //for white kamen, iza l value bil child is 5, laken set the heuristic to -5, wa 2illa it's only from 0 to 5. ---> this is exclusivity to win
        

////////////////////////////INSERT CHAINS IN PRIORITY QUEUE....shufon min il magnetic cave check win function, the ones above 2, are added to a priority queue
        ////////////////////and that priority queue will be taken into consideration when computing/calculating values
        //check if we have a tie, shu mna3mol

        //System.out.println("BlackValue: " + blackValue);
        //System.out.println("WhiteValue: " + whiteValue);

        //System.out.println("GRID:\n" + node.currentState + "\n");
        //System.out.print("Heuristic: " + heuristic + "\n");
       return heuristic;
    }

    public static Position look_Max(MMTree root, int level)
    {
        lookAheadTill(root, root, 0, level);

        //System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\\n\n\n\n\n\n\n\n\n\n\n\n");
        //root.levelOrderPrint();
        //System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\\n\n\n\n\n\n\n\n\n\n\n\n");

        //assign heuristics to the level
        //System.out.println("\n\nPrinting Last Level Values: ");

        ListIterator lastLevelitr = root.lastLevel.listIterator();

        while(lastLevelitr.hasNext())
        {
            MMTree current = ((MMTree) lastLevelitr.next());
            current.value = computeHeuristic(current); //compute value;
            //System.out.print(current.value + " ");
        }

                

        minimaxForLevel(root, root, 0, level);
        //alphabetaForLevel(root, root, 0, level);

        
        //System.out.println("\nLook MAX:\n");

        int value = 0;
        int index = 0;

        if (root.isMax())
            value = -999;
        else
            value = 9999;
        

            ListIterator selector = root.children.listIterator();
            
            /*
            if (selector.hasNext())
            {
                value = ((MMTree) selector.next()).value;
            }
            */
            ArrayList<Integer> min = new ArrayList<Integer>();
            ArrayList<Integer> max = new ArrayList<Integer>();

            
            while (selector.hasNext())
            {
                    int currentValue = ((MMTree) selector.next()).value;

                    if (root.isMax())
                    {
                        if (value < currentValue)
                        {
                            value = currentValue;

                            max.clear();
                            max.add(index);


                        }
                        else
                            if (value == currentValue)
                            {
                                max.add(index);
                            }

                        index = index + 1;


                    }
                    else
                    {
                        if (value > currentValue)
                        {
                            value = currentValue;
                            min.clear();
                            min.add(index);

                        }
                        else
                            if (value == currentValue)
                            {
                                min.add(index);
                            }

                        index = index + 1;

                    }


                    //System.out.println("Value: " + currentValue);
                    //System.out.println("Root is Max");
                    //System.out.println("Final Value: " + value + "\n");

            }

            
            

            //System.out.println("Index Chosen: " + index + "\n");

            int chosenIndex = 0;


            Position toTake;// = root.children.get(index).move;

            if (root.isMax())
            {
                chosenIndex = (int)(Math.random()*max.size());
                int trueIndex = max.get(chosenIndex);
                //System.out.println("\n\nTRUEINDEX: " + trueIndex +"\n\n");
                toTake = root.children.get(trueIndex).move;

            }
            else
            {
                chosenIndex = (int)(Math.random()*min.size());
                int trueIndex = min.get(chosenIndex);
                //System.out.println("\n\nTRUEINDEX: " + trueIndex +"\n\n");

                toTake = root.children.get(trueIndex).move;

            }


        return toTake;
        
    }

    

    
    public void levelOrderPrintCaves()
    {
        if (this.parent == null)
        {
            System.out.println("Level Order:");
        }


        q.put(this);

        while (!(q.isEmpty()))
        {
            MMTree c = (MMTree) q.remove();
            System.out.println(c.currentState + "\n");

            ListIterator itr = c.children.listIterator();

            while (itr.hasNext())
            {
                q.put((MMTree) itr.next());
            }

        }

    }


    public static void main(String[] argv)
    {
        
        /*
        MMTree self = new MMTree();

        self.addChild(new MMTree());
        self.addChild(new MMTree());
        self.addChild(new MMTree());


        self.children.get(0).addChild(new MMTree());
        self.children.get(0).addChild(new MMTree());
        self.children.get(0).addChild(new MMTree());


        self.children.get(0).children.get(0).addChild(new MMTree(4));
        self.children.get(0).children.get(0).addChild(new MMTree(5));


        self.children.get(0).children.get(1).addChild(new MMTree(8));
        self.children.get(0).children.get(1).addChild(new MMTree(4));

        self.children.get(0).children.get(2).addChild(new MMTree(6));
        self.children.get(0).children.get(2).addChild(new MMTree(9));




        self.children.get(1).addChild(new MMTree());
        self.children.get(1).addChild(new MMTree());


        self.children.get(1).children.get(0).addChild(new MMTree(0));
        self.children.get(1).children.get(0).addChild(new MMTree(2));

        self.children.get(1).children.get(1).addChild(new MMTree(7));
        self.children.get(1).children.get(1).addChild(new MMTree(1));




        self.children.get(2).addChild(new MMTree());
        self.children.get(2).addChild(new MMTree());


        self.children.get(2).children.get(0).addChild(new MMTree(8));
        self.children.get(2).children.get(0).addChild(new MMTree(6));


        self.children.get(2).children.get(1).addChild(new MMTree(9));
        self.children.get(2).children.get(1).addChild(new MMTree(5));

        self.levelOrderPrint();
        alphabetaForLevel(self, self, 0, 3);
        System.out.println("\n");
        self.levelOrderPrint();
        System.out.println("\n");
        */
        
        
        MMTree test = new MMTree();

        boolean blackConsWins = false;
        boolean whiteConsWins = false;


        System.out.println("Starting Game:\n");

        System.out.println("Enter\n1 for manual entry for Both Players' moves\n2 for Manual entry for Black Player & automatic moves for White Player\n3 for Manual entry for White Player & automatic moves for Black Player\n\n\n\n\n4 for automatic moves for Both Players");
        Scanner scan2 = new Scanner(System.in);
        int option = scan2.nextInt();

        System.out.println("Initial Grid:\n" + test.currentState);
        //test.levelOrderPrint();

        if (option == 1)
        {
            while (true)
            {
                int row = 0;
                char column = '0';

                while (true)
                {
                    boolean skip = false;

                    Position suggested = look_Max(test, 3); //Minimax suggest a certain move

                    //test.levelOrderPrint();
                    //postOrderPrint(test);

                    System.out.println("\nMinimax suggests taking Position:\nRow: " + suggested.row + "\nColumn: " + ((char) (suggested.col + 65)) + "\n\n");


                    if (test.blackTurn == true)
                    {
                        System.out.println("Black, enter your move:");
                    }
                    else
                    {
                        System.out.println("White, enter your move:");
                    }

                    //lookAheadTill(test, test, 0, 3);


                    System.out.println("Row:");
                    Scanner scan = new Scanner(System.in);
                    row = scan.nextInt();


                    System.out.println("\nColumn:");

                    InputStreamReader inp = new InputStreamReader(System.in);
                    BufferedReader br = new BufferedReader(inp);

                    while (true)
                    {
                        try
                        {
                            column = (char) br.read();
                            break;
                        }
                        catch (IOException ex)
                        {
                            System.err.println("Error reading column, try again");

                        }

                    }

                    try
                    {
                        test.addMove(row, column);
                        break;
                    }
                    catch (Exception e)
                    {
                        System.err.println("Incorrect Position, try again");

                    }

                }
                
                if ((test.currentState.checkWin(row, column)) && (test.blackTurn == true))
                {
                    blackConsWins = false;//black rebe7
                    whiteConsWins = true;
                }
                else
                    if ((test.currentState.checkWin(row, column)) && (test.blackTurn == false))
                    {
                        whiteConsWins = false;//white rebe7
                        blackConsWins = true;
                    }




                System.out.println("Grid:\n" + test.currentState + "\n");
                
                
                if ((blackConsWins == true) || (whiteConsWins == true || (test.currentState.full())))
                {
                    break;
                }

            }
        }
        else
            if (option == 2)
            {
                while (true)
                {
                    int row = 0;
                    char column = '0';
                    //int columnNumerical = 0;

                    while (true)
                    {
                        boolean skip = false;

                        Position suggested = look_Max(test, 3); //Minimax suggest a certain move
                        
                        //test.levelOrderPrint();
                    //postOrderPrint(test);

                        if (test.blackTurn == true)
                        {
                            System.out.println("\nMinimax suggests taking Position:\nRow: " + suggested.row + "\nColumn: " + (char) (suggested.col + 65) + "\n\n");
                            System.out.println("Black, enter your move:");
                            System.out.println("Row:");
                            Scanner scan = new Scanner(System.in);
                            row = scan.nextInt();


                            System.out.println("\nColumn:");

                            InputStreamReader inp = new InputStreamReader(System.in);
                            BufferedReader br = new BufferedReader(inp);

                            while (true)
                            {
                                try
                                {
                                    column = (char) br.read();
                                    break;
                                }
                                catch (IOException ex)
                                {
                                    System.err.println("Error reading column, try again");

                                }

                            }

                        }
                        else
                        {
                            System.out.println("\nComputer chose position:\nRow: " + suggested.row + "\nColumn: " + (char) (suggested.col + 65) + "\n\n");
                            row = suggested.row;
                            //columnNumerical = suggested.col;
                            column = (char) (suggested.col + 65);
                            
                        }


                        try
                        {
                            test.addMove(row, column);
                            //hone code to add wins 7asab la min
                            break;
                        }
                        catch (Exception e)
                        {
                            System.err.println("Incorrect Position, try again");
                        }
                        
                    }

                                        
                    
                    if ((test.currentState.checkWin(row, column)) && (test.blackTurn == true)) //iza dor l black, ya3ne last move was white...ya3ne white is winner
                    {
                        blackConsWins = false;//black rebe7
                        whiteConsWins = true;
                    }
                    else
                        if ((test.currentState.checkWin(row, column)) && (test.blackTurn == false))
                        {
                            whiteConsWins = false;//white rebe7
                            blackConsWins = true;
                        }

                    System.out.println("Grid:\n" + test.currentState + "\n");


                    if ((blackConsWins == true) || (whiteConsWins == true || (test.currentState.full())))
                    {
                        break;
                    }

                }




            }
            else
                if (option == 3)
                {

                    while (true)
                    {
                        int row = 0;
                        char column = '0';
                        int columnNumerical = 0;

                        while (true)
                        {
                            boolean skip = false;

                            Position suggested = look_Max(test, 3); //Minimax suggest a certain move

                            //test.levelOrderPrint();
                    //postOrderPrint(test);

                            if (test.blackTurn == false)
                            {
                                System.out.println("\nMinimax suggests taking Position:\nRow: " + suggested.row + "\nColumn: " + (char) (suggested.col + 65) + "\n\n");
                                System.out.println("White, enter your move:");
                                System.out.println("Row:");
                                Scanner scan = new Scanner(System.in);
                                row = scan.nextInt();


                                System.out.println("\nColumn:");

                                InputStreamReader inp = new InputStreamReader(System.in);
                                BufferedReader br = new BufferedReader(inp);

                                while (true)
                                {
                                    try
                                    {
                                        column = (char) br.read();
                                        break;
                                    }
                                    catch (IOException ex)
                                    {
                                        System.err.println("Error reading column, try again");

                                    }

                                }


                            }
                            else
                            {
                                System.out.println("\nComputer chose position:\nRow: " + suggested.row + "\nColumn: " + (char) (suggested.col + 65) + "\n\n");
                                row = suggested.row;
                                //columnNumerical = suggested.col;
                                column = (char) (suggested.col + 65);

                            }

                            try
                            {
                                test.addMove(row, column);

                                //hone code to add wins 7asab la min
                                break;

                            }
                            catch (Exception e)
                            {
                                System.err.println("Incorrect Position, try again");

                            }


                        }

                        


                        if ((test.currentState.checkWin(row, column)) && (test.blackTurn == true))
                        {
                            blackConsWins = false;//black rebe7
                            whiteConsWins = true;
                        }
                        else
                            if ((test.currentState.checkWin(row, column)) && (test.blackTurn == false))
                            {
                                whiteConsWins = false;//white rebe7
                                blackConsWins = true;
                            }

                        System.out.println("Grid:\n" + test.currentState + "\n");


                        if ((blackConsWins == true) || (whiteConsWins == true || (test.currentState.full())))
                        {
                            break;
                        }

                    }


                }
                else
                    if (option == 4)
                    {
                        while (true)
                        {
                            int row = 0;
                            char column = '0';
                            int columnNumerical = 0;

                            while (true)
                            {
                                boolean skip = false;

                                Position suggested = look_Max(test, 3); //Minimax suggest a certain move

                                //test.levelOrderPrint();
                    //postOrderPrint(test);

                                if (test.blackTurn == true)
                                {
                                    System.out.println("\nBlack chose this Position:\nRow: " + suggested.row + "\nColumn: " + (char) (suggested.col + 65) + "\n\n");
                                    
                                    row = suggested.row;
                                    column = (char) (suggested.col + 65);
                                    
                                }
                                else
                                {
                                    System.out.println("\nWhite chose position:\nRow: " + suggested.row + "\nColumn: " + (char) (suggested.col + 65) + "\n\n");
                                    row = suggested.row;
                                    //columnNumerical = suggested.col;
                                    column = (char) (suggested.col + 65);

                                }

                                try
                                {
                                    test.addMove(row, column);

                                    //hone code to add wins 7asab la min
                                    break;

                                }
                                catch (Exception e)
                                {
                                    System.err.println("Incorrect Position, try again");
                                }


                            }




                            if ((test.currentState.checkWin(row, column)) && (test.blackTurn == true))
                            {
                                blackConsWins = false;//black rebe7
                                whiteConsWins = true;
                            }
                            else
                                if ((test.currentState.checkWin(row, column)) && (test.blackTurn == false))
                                {
                                    whiteConsWins = false;//white rebe7
                                    blackConsWins = true;
                                }

                            System.out.println("Grid:\n" + test.currentState + "\n");


                            if ((blackConsWins == true) || (whiteConsWins == true || (test.currentState.full())))
                            {
                                break;
                            }

                        }


                }


        if (blackConsWins == true)
        {
            System.out.println("Black Player has won the game");
        }

        if (whiteConsWins == true)
        {
            System.out.println("White Player has won the game");
        }
    
    
    
    
    }

    
}
