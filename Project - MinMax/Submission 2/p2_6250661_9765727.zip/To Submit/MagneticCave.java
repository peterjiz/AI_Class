//
//  MagneticCave.java
//  MagneticCave
//
//  Created by Peter El Jiz & Kevin El-Hage on 2012-11-09.
//  Copyright (c) 2012 Peter El Jiz & Kevin El-Hage. All rights reserved.
//


import java.util.ArrayList;
import java.util.ListIterator;

public class MagneticCave
{
    //our Data Structures
    private int[][] grid; //row, column
    private ArrayList<Position> possibleMoves;
    //private MMTree minimaxTree;
    private boolean blackturn = true;


    private boolean blackWin = false;
    private boolean whiteWin = false;


    //private ArrayList<Position> newMoves;
    //private boolean started = false;


    
    public ArrayList<Position> getpossibleMoves()
    {
        return possibleMoves;
    }

    /*
    public ArrayList<Position> getnewMoves()
    {
        return newMoves;
    }
    */

    public boolean getblackturn()
    {
        return blackturn;
    }

    public boolean full()
    {
        for (int i = 1; i < 9; ++i)
            for (int j = 0; j < 8; ++j)
                if (grid[i][j] == 0)
                    return false;
        
        return true;
    }

    public void setblackturn(boolean flag)
    {
        this.blackturn = flag;
    }


    public MagneticCave()
    {
        grid = new int[9][8]; //row, column
        possibleMoves = new ArrayList();
        //minimaxTree = new MMTree();

        for (int i = 1; i < 9; i++)
        {
            possibleMoves.add(new Position(i, 0));
            possibleMoves.add(new Position(i, 7));
        }


        /*
        for (int i = 1; i < 9; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                grid[i][j] = -1;
            }

        }
        */


    }

    public MagneticCave(MagneticCave old)
    {
        grid = new int[9][8];
        
        for (int i = 1; i < 9; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                grid[i][j] = old.grid[i][j];
            }

        }

        //grid = old.grid; //row, column
        possibleMoves = new ArrayList();

        ListIterator itr = old.possibleMoves.listIterator();
        //itr.next();

        while (itr.hasNext())
        {
            Position temp = (Position) itr.next();
            //System.out.println("\nPossible Move:\nRow:" + temp.row + "\nCol:" + temp.col + "\n");
            possibleMoves.add(temp);
        }
        //started = true;
        
    }
    

    public void addToGrid(int row, char column) throws Exception
    {
        /*
        if (started == false)
        {
            started = true;
            blackturn = true;
        }
        */
        
        if ( (column >= 'a') && (column <= 'z'))
        {
            column = (char) (((int) column) - 32);
        }


        if ((row < 1) || (row > 8) || (column < 'A') || (column > 'H'))
            throw new Exception();


        int trueColumn = column - 65;
        int trueRow = row; //to make row - 1....for now 3am neshtghel tameman mitil l grid.


        //System.out.println("Character is: " + column);
        //System.out.println("TrueRow is: " + trueRow);
        //System.out.println("TrueColumn is: " + trueColumn);


        //if ( ((trueColumn == 0) || (trueColumn == 7)) || ((grid[trueRow][trueColumn] == 0) && ((grid[trueRow][trueColumn-1] != 0) || (grid[trueRow][trueColumn+1] != 0))))
        if ((grid[trueRow][trueColumn] == 0))
        {
            if ((trueColumn == 0) || (trueColumn == 7) || (grid[trueRow][trueColumn-1] != 0) || (grid[trueRow][trueColumn+1] != 0))
            {
                //System.out.println("HERE\n");

                if (blackturn == true) {
                    grid[trueRow][trueColumn] = 1;
                    blackturn = false;

                } else if (blackturn == false) {
                    grid[trueRow][trueColumn] = 2;
                    blackturn = true;
                }

                //remove used position
                possibleMoves.remove(new Position(trueRow, trueColumn));
                possibleMoves.remove(new Position(trueRow, trueColumn));

                //add to list of possible positions
                if (((trueColumn - 1) > 0) && (grid[trueRow][trueColumn - 1] == 0))
                {
                    possibleMoves.add(new Position(trueRow, trueColumn - 1));
                    //newMoves.add(new Position(trueRow, trueColumn - 1));
                }

                if (((trueColumn + 1) < 8) && (grid[trueRow][trueColumn + 1] == 0))
                {
                    possibleMoves.add(new Position(trueRow, trueColumn + 1));
                    //newMoves.add(new Position(trueRow, trueColumn + 1));

                }

            }
            else
                throw new Exception();

        }
        else
            throw new Exception();

        
    }





    public void addToGrid(int row, int column) throws Exception
    {
        if ((row < 1) || (row > 8) || (column < 0) || (column > 8))
            throw new Exception();


        int trueColumn = column;
        int trueRow = row; //to make row - 1....for now 3am neshtghel tameman mitil l grid.


        //System.out.println("Character is: " + column);
        //System.out.println("TrueRow is: " + trueRow);
        //System.out.println("TrueColumn is: " + trueColumn);


        /*
        //if ( (trueColumn == 0) || (trueColumn == 7) || (grid[trueRow][trueColumn-1] != 0) || (grid[trueRow][trueColumn+1] != 0))
        if ( ((trueColumn == 0) || (trueColumn == 7)) || ((grid[trueRow][trueColumn] == 0) && ((grid[trueRow][trueColumn-1] != 0) || (grid[trueRow][trueColumn+1] != 0))))
        {
            //System.out.println("HERE\n");

            if (blackturn == true)
            {
                grid[trueRow][trueColumn] = 1;
                blackturn = false;

            }
            else
                if (blackturn == false)
                {
                    grid[trueRow][trueColumn] = 2;
                    blackturn = true;
                }

            //remove used position
            possibleMoves.remove(new Position(trueRow, trueColumn));

            //add to list of possible positions
            if ( ((trueColumn - 1) > 0 ) && (grid[trueRow][trueColumn-1] == 0) )
                possibleMoves.add(new Position(trueRow, trueColumn-1));

            if ( ((trueColumn + 1) < 8 ) && (grid[trueRow][trueColumn+1] == 0) )
                possibleMoves.add(new Position(trueRow, trueColumn+1));


        }
        else
            throw new Exception();
        */

        if ((grid[trueRow][trueColumn] == 0))
        {
            if ((trueColumn == 0) || (trueColumn == 7) || (grid[trueRow][trueColumn - 1] != 0) || (grid[trueRow][trueColumn + 1] != 0))
            {
                //System.out.println("HERE\n");

                if (blackturn == true)
                {
                    grid[trueRow][trueColumn] = 1;
                    blackturn = false;

                }
                else
                    if (blackturn == false)
                    {
                        grid[trueRow][trueColumn] = 2;
                        blackturn = true;
                    }

                //remove used position
                possibleMoves.remove(new Position(trueRow, trueColumn));

                //add to list of possible positions
                if (((trueColumn - 1) > 0) && (grid[trueRow][trueColumn - 1] == 0))
                {
                    possibleMoves.add(new Position(trueRow, trueColumn - 1));
                }

                if (((trueColumn + 1) < 8) && (grid[trueRow][trueColumn + 1] == 0))
                {
                    possibleMoves.add(new Position(trueRow, trueColumn + 1));
                }

            }
            else
                throw new Exception();
        }
        else
        {
            throw new Exception();
        }



    }


    public boolean checkWin(int row, char column)
    {
        if ( (column >= 'a') && (column <= 'z'))
        {
            column = (char) (((int) column) - 32);
        }


        if ((row < 1) || (row > 8) || (column < 'A') || (column > 'H'))
            return false;


        int trueColumn = column - 65;
        int trueRow = row;

        return (this.checkWin(trueRow, trueColumn));

    }

    public boolean checkWin(int row, int col)
    {
        return ((this.horizontalWin(row, col) == true) || (this.verticalWin(row, col) == true) || (this.diagonalWin(row, col) == true));
    }

    

    public boolean horizontalWin(int row, int col)
    {
        boolean black = false;
        
        if (grid[row][col] == 1)
            black = true;
        else
            if (grid[row][col] == 2)
                black = false;

        

        int leftCounter = 0;
        int rightCounter = 0;
        int total = 0;

        boolean stopCheckingLeft = false;
        boolean stopCheckingRight = false;


        if (black == true)
        {
            while (((leftCounter < 5) && (rightCounter < 5)) && ((stopCheckingLeft == false) || (stopCheckingRight == false)))
            {
                if (stopCheckingRight == false)
                    if ((rightCounter + col < 8) && ((grid[row][rightCounter + col] == 1))) // || ((grid[row][rightCounter+col] == 0)) ))
                        rightCounter++;
                    else
                        stopCheckingRight = true;//stop checking right//insa l bansa



                //if ( (col-leftCounter > 0) && ((grid[row][col-leftCounter] == 2) || ((grid[row][col-leftCounter] == 0)) ))
                if (stopCheckingLeft == false)
                    if ((col - leftCounter >= 0) && ((grid[row][col - leftCounter] == 1)))// || ((grid[row][rightCounter+col] == 0)) ))
                        leftCounter++;
                    else
                        stopCheckingLeft = true;//stop checking left;

            }

        }
        else
        {
            while (((leftCounter < 5) && (rightCounter < 5)) && ((stopCheckingLeft == false) || (stopCheckingRight == false)))
            {

                if (stopCheckingRight == false)
                    if ((rightCounter + col < 8) && ((grid[row][rightCounter + col] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        rightCounter++;
                    else
                        stopCheckingRight = true;//stop checking right//insa l bansa



                if (stopCheckingLeft == false)
                    if ((col - leftCounter >= 0) && ((grid[row][col - leftCounter] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        leftCounter++;
                    else
                        stopCheckingLeft = true;//stop checking left;
                
            }

        }

        total = leftCounter + rightCounter -1;

        if (total >=5)
            return true;//WINNER

        return false;

    }











    
    public boolean verticalWin(int row, int col)
    {
        boolean black = false;

        if (grid[row][col] == 1)
            black = true;
        else
            if (grid[row][col] == 2)
                black = false;



        int downCounter = 0;
        int upCounter = 0;
        int total = 0;

        boolean stopCheckingUp = false;
        boolean stopCheckingDown = false;


        if (black == true)
        {
            while (((downCounter < 5) && (upCounter < 5)) && ((stopCheckingDown == false) || (stopCheckingUp == false)))
            {
                if (stopCheckingUp == false)
                    if ((upCounter + row < 9) && ((grid[row+upCounter][col] == 1))) // || ((grid[row][rightCounter+col] == 0)) ))
                        upCounter++;
                    else
                        stopCheckingUp = true;//stop checking right//insa l bansa



                //if ( (col-leftCounter > 0) && ((grid[row][col-leftCounter] == 2) || ((grid[row][col-leftCounter] == 0)) ))
                if (stopCheckingDown == false)
                    if ((row - downCounter > 0) && ((grid[row-downCounter][col] == 1)))// || ((grid[row][rightCounter+col] == 0)) ))
                        downCounter++;
                    else
                        stopCheckingDown = true;//stop checking left;

            }

        }
        else
        {
            while (((downCounter < 5) && (upCounter < 5)) && ((stopCheckingDown == false) || (stopCheckingUp == false)))
            {

                if (stopCheckingUp == false)
                    if ((upCounter + row < 9) && ((grid[row+upCounter][col] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        upCounter++;
                    else
                        stopCheckingUp = true;//stop checking right//insa l bansa



                if (stopCheckingDown == false)
                    if ((row - downCounter > 0) && ((grid[row - downCounter][col] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        downCounter++;
                    else
                        stopCheckingDown = true;//stop checking left;

            }

        }

        total = downCounter + upCounter - 1;

        if (total >=5)
            return true;//WINNER

        return false;

    }


    public boolean diagonalWin(int row, int col)
    {
        return ((this.downLeftToUpRightdiagonalWin(row, col)) || (this.downRightToUpLeftdiagonalWin(row, col)));
    }



    public boolean downLeftToUpRightdiagonalWin(int row, int col)
    {
        boolean black = false;

        if (grid[row][col] == 1)
            black = true;
        else
            if (grid[row][col] == 2)
                black = false;



        int downLeftCounter = 0;
        int upRightCounter = 0;
        int total = 0;

        boolean stopCheckingUpRight = false;
        boolean stopCheckingDownLeft = false;


        if (black == true)
        {
            while (((downLeftCounter < 5) && (upRightCounter < 5)) && ((stopCheckingDownLeft == false) || (stopCheckingUpRight == false)))
            {
                if (stopCheckingUpRight == false)
                    if ((upRightCounter + row < 9) && (upRightCounter + col < 8) && ((grid[row+upRightCounter][col+upRightCounter] == 1))) // || ((grid[row][rightCounter+col] == 0)) ))
                        upRightCounter++;
                    else
                        stopCheckingUpRight = true;//stop checking right//insa l bansa


                if (stopCheckingDownLeft == false)
                    if ((row - downLeftCounter > 0) && (col - downLeftCounter >= 0) && ((grid[row-downLeftCounter][col-downLeftCounter] == 1)))// || ((grid[row][rightCounter+col] == 0)) ))
                        downLeftCounter++;
                    else
                        stopCheckingDownLeft = true;//stop checking left;

            }

        }
        else
        {
            while (((downLeftCounter < 5) && (upRightCounter < 5)) && ((stopCheckingDownLeft == false) || (stopCheckingUpRight == false)))
            {

                if (stopCheckingUpRight == false)
                    if ((upRightCounter + row < 9) && (upRightCounter + col < 8) && ((grid[row+upRightCounter][col+upRightCounter] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        upRightCounter++;
                    else
                        stopCheckingUpRight = true;//stop checking right//insa l bansa



                if (stopCheckingDownLeft == false)
                    if ((row - downLeftCounter > 0) && (col - downLeftCounter >= 0) && ((grid[row-downLeftCounter][col-downLeftCounter] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        downLeftCounter++;
                    else
                        stopCheckingDownLeft = true;//stop checking left;

            }

        }

        total = downLeftCounter + upRightCounter - 1;

        if (total >=5)
            return true;//WINNER

        return false;

    }



    private boolean downRightToUpLeftdiagonalWin(int row, int col)
    {
        
        boolean black = false;

        if (grid[row][col] == 1)
            black = true;
        else
            if (grid[row][col] == 2)
                black = false;



        int downRightCounter = 0;
        int upLeftCounter = 0;
        int total = 0;

        boolean stopCheckingUpLeft = false;
        boolean stopCheckingDownRight = false;


        if (black == true)
        {
            while (((downRightCounter < 5) && (upLeftCounter < 5)) && ((stopCheckingDownRight == false) || (stopCheckingUpLeft == false)))
            {
                if (stopCheckingUpLeft == false)
                    if ((upLeftCounter + row < 9) && (col - upLeftCounter >= 0) && ((grid[row+upLeftCounter][col-upLeftCounter] == 1))) // || ((grid[row][rightCounter+col] == 0)) ))
                        upLeftCounter++;
                    else
                        stopCheckingUpLeft = true;//stop checking right//insa l bansa


                if (stopCheckingDownRight == false)
                    if ((row - downRightCounter > 0) && (col + downRightCounter < 8) && ((grid[row-downRightCounter][col+downRightCounter] == 1)))// || ((grid[row][rightCounter+col] == 0)) ))
                        downRightCounter++;
                    else
                        stopCheckingDownRight = true;//stop checking left;

            }

        }
        else
        {
            while (((downRightCounter < 5) && (upLeftCounter < 5)) && ((stopCheckingDownRight == false) || (stopCheckingUpLeft == false)))
            {

                if (stopCheckingUpLeft == false)
                    if ((upLeftCounter + row < 9) && (col - upLeftCounter >= 0) && ((grid[row+upLeftCounter][col-upLeftCounter] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        upLeftCounter++;
                    else
                        stopCheckingUpLeft = true;//stop checking right//insa l bansa



                if (stopCheckingDownRight == false)
                {
                    //System.out.println("Row - DownRightCounter: " + row + " - " + downRightCounter + " = " + (row-downRightCounter));

                    if ((row - downRightCounter > 0) && (col + downRightCounter < 8) && ((grid[row-downRightCounter][col+downRightCounter] == 2)))// || ((grid[row][rightCounter+col] == 0)) ))
                        downRightCounter++;
                    else
                        stopCheckingDownRight = true;//stop checking left;
                }
            }

        }

        total = downRightCounter + upLeftCounter - 1;

        if (total >=5)
            return true;//WINNER

        return false;
        
    }






















    public String toString()
    {
        String result = "";
        result = "\t A\tB\tC\tD\tE\tF\tG\tH\n";

        for (int i = 8; i > 0; i--)
        {
            result += i;
            
            for (int j = 0; j < 8; j++)
            {
                result += "\t" + this.grid[i][j];
            }

            result += "\n";
            //result += "\n" + i;
        }

        return result;
    }

    
}
