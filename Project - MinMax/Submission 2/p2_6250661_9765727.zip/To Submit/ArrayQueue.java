//
//  ArrayQueue.java
//  MMTree
//
//  Created by Peter El Jiz & Kevin El-Hage on 2012-10-19.
//  Copyright (c) 2012 Peter El Jiz & Kevin El-Hage. All rights reserved.
//

public class ArrayQueue
{
    private static final int DEFAULT_CAPACITY=200;
    private int end_index;
    private int start_index;
    private Object[] array;

    public ArrayQueue(int capacity)
    {
        array = new Object[capacity];
        end_index = 0;
        start_index = 0;
    }

    public ArrayQueue()
    {
        this(DEFAULT_CAPACITY);
    }

    public void put(Object obj)
    {
        if ((start_index + this.end_index) >= array.length)
        {
            this.enlarge();
            array[end_index] = obj;
            end_index++;

        }
        else
        {
            array[end_index]=obj;
            end_index++;
        }
    }

    public Object remove()
    {
        Object temp = array[start_index];
        array[start_index] = null;
        start_index++;
        return temp;
    }


    private void enlarge()
    {
        Object[] temp_array = new Object[(this.array.length)*2];

        int temp_array_end_index = 0;
        if ( (end_index - start_index) >0)
        {
            for (int i=start_index; i < end_index; i++)
            {
                temp_array[i-start_index] = array[i];
                temp_array_end_index++;

            }

            this.array = temp_array;
            this.end_index = temp_array_end_index;
            this.start_index = 0;
        }
        else
        {
            array = temp_array;
        }

    }

    public boolean isEmpty()
    {
        return ( (end_index - start_index) == 0);
    }

    public Object getFrontElement()
    {
        return array[start_index];
    }

    public Object getRearElement()
    {
        return array[end_index - 1];
    }


}
