//
//  Position.java
//  Position
//
//  Created by Peter El Jiz & Kevin El-Hage on 2012-11-09.
//  Copyright (c) 2012 Peter El Jiz & Kevin El-Hage. All rights reserved.
//

public class Position
{
    int row;
    int col;


    /*
    Position()
    {
        row = 0;
        col = 0;
    }
     */
    
    Position(int r, int c)
    {
        row = r;
        col = c;

    }

    public boolean equals(Object p)
    {
        return ((this.row == ((Position) p).row) && (this.col == ((Position) p).col));
    }


}
