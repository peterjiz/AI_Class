//
//  MMTree.java
//  MMTree
//
//  Created by Peter El Jiz & Kevin El-Hage on 2012-10-19.
//  Copyright (c) 2012 Peter El Jiz & Kevin El-Hage. All rights reserved.
//

//import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
//import java.util.ArrayList;


public class MMTree
{
    private int value;
    private boolean isMax;
    private boolean isMin;
    private boolean assigned;

    private MMTree parent;
    private List<MMTree> children;

    private int best_child;

    private MMTree next;

    ArrayStack s = new ArrayStack(200);
    ArrayQueue q = new ArrayQueue(500);

    public MMTree()
    {
        if (parent == null)
        {
            isMax = true;
            //this.value = 9999;
        }
        

        this.value = value;
        children = new LinkedList<MMTree>();

        assigned = false;
    }

    public MMTree(int value)
    {

        this.value = value;
        children = new LinkedList<MMTree>();
        assigned = true;

    }

    public void addChild(MMTree ch)
    {
        if (this.isMax == true)
        {
            ch.isMax = false;
            //if (ch.value == 0)
                //ch.value = 9999;
        }
        else
        {
            ch.isMax = true;
            //if (ch.value == 0)
                //ch.value = -9999;
        }

        children.add(ch);
        ch.parent = this;



    }

    public void pruneTree(MMTree ch)
    {
        children.remove(ch);
        ch.parent = null;

        //deleteTree(ch);

    }

    public static void pruneChildren(MMTree ch)
    {
        ListIterator itr = ch.children.listIterator();
        itr.next();

        while (itr.hasNext())
        {
            ((MMTree) itr.next()).parent = null;
            itr.remove();
        }


        //deleteTree(ch);

    }

    public void deleteTree(MMTree ch)
    {
        /*
        ch.children
        deleteTree(ch.);
        */
        
    }

    public boolean isMax()
    {
        return isMax;
    }


    public boolean isLeaf()
    {
        return children.isEmpty();
    }

    public MMTree getParent()
    {
        return parent;
    }

    public static void preOrder(MMTree t)
    {

    }



    public static void minimax(MMTree c)
    {


        ListIterator itr = c.children.listIterator();


        
        if (!(c.isLeaf()))
        {
            while (itr.hasNext())
            {
                minimax((MMTree) itr.next());
            }
        }



        if (c.parent != null)
{


    int father = c.parent.value;
    int son = c.value;

    boolean parentMax = c.parent.isMax;




    if (c.parent.assigned == false)
    {
        c.parent.value = c.value;
        c.parent.assigned = true;
    }

                if (parentMax == true)
                {

                    if (father < son)
                    {



                        c.parent.value = son;


                    }
                }
                else
                {


                    if (father > son)
                    {



                        c.parent.value = son;






                    }

                

            }
        }






    }











    public static void minimaxForLevel(MMTree c, int level, int maxLevel)
    {
        
        ListIterator itr = c.children.listIterator();


        if (level < maxLevel)
        {
            System.out.println("HERE");
            while (itr.hasNext())
            {
                minimaxForLevel(((MMTree) itr.next()), level+1, maxLevel);
            }
        }



if (c.parent != null)
{
    int father = c.parent.value;
    int son = c.value;

    boolean parentMax = c.parent.isMax;



    if (c.parent.assigned == false)
    {
        c.parent.value = c.value;
        c.parent.assigned = true;
    }

                if (parentMax == true)
                {
                    if (father < son)
                    {


                        c.parent.value = son;

                    }
                }
                else
                {

                    if (father > son)
                    {
                        c.parent.value = son;


                    }



            }
        }

    }












    public static void alphabeta(MMTree c) //this method still doesn't work yet...I'm in the process of writing it
    {
        ListIterator itr = c.children.listIterator();


        if (!(c.isLeaf()))
        {
            alphabeta((MMTree) itr.next());
        }


        /*
        //parent code
        if (c.parent != null)
        {
            if (c.parent.isMax())
            {
                if (c.parent.value > c.value) //parent akbar minne w parent maximum
                {
                    pruneChildren(c);
                }
            }
            else
            {//iza parent minimum
                if (c.parent.value < c.value) //parent azghar minne w parent minimum
                {
                    pruneChildren(c);
                }
            }

        }
        */

        if (!(c.isLeaf()))
        {
            while (itr.hasNext())
            {
                alphabeta((MMTree) itr.next());
            }

        }

        if (c.parent != null)
        {
            int father = c.parent.value;
            int son = c.value;

            boolean parentMax = c.parent.isMax;

            if (c.parent.assigned == false)
            {
                c.parent.value = c.value;
                c.parent.assigned = true;
            }

            if (parentMax == true)
            {
                if (father < son)
                {
                    c.parent.value = son;
                }
            }
            else
            {
                if (father > son)
                {
                    c.parent.value = son;
                }

            }
        }

    }


    


    public void levelOrderPrint()
    {
        if (this.parent == null)
            System.out.println("Level Order:");


        q.put(this);

        while (!(q.isEmpty()))
        {
            MMTree c = (MMTree) q.remove();
            System.out.print(c.value + " ");

            ListIterator itr = c.children.listIterator();

            while (itr.hasNext())
            {
                q.put((MMTree) itr.next());
            }

        }

    }


    public static void preOrderPrint(MMTree c)
    {
        if (c.parent == null)
            System.out.println("Pre Order:");

        System.out.print(c.value + " ");

        ListIterator itr = c.children.listIterator();


        if (!(c.isLeaf()))
        {
            while (itr.hasNext())
            {
                preOrderPrint((MMTree) itr.next());
            }
        }


    }

    public static void postOrderPrint(MMTree c)
    {
        if (c.parent == null)
            System.out.println("Post Order:");

        ListIterator itr = c.children.listIterator();


        if (!(c.isLeaf()))
        {
            while (itr.hasNext())
            {
                postOrderPrint((MMTree) itr.next());
            }
        }


        System.out.print(c.value + " ");
        

    }


    //INORDER VARIATION Print...not applicatable though, because inorder is for binary trees (left-root-right)
    /*
    public static void inOrderPrint(MMTree c)
    {
        if (c.parent == null)
            System.out.println("InOrder Order:");

        ListIterator itr = c.children.listIterator();


        if (!(c.isLeaf()))
        {
            if (itr.hasNext())
            {
                inOrderPrint((MMTree) itr.next());
            }
        }


        System.out.print(c.value + " ");


        if (!(c.isLeaf()))
        {
            if (itr.hasNext())
            {
                inOrderPrint((MMTree) itr.next());
            }
        }

    }
*/


    public static MMTree generateRandomNumbersTree()
    {
        MMTree randomTree = new MMTree();
        
        randomTree.addChild(new MMTree());
        randomTree.addChild(new MMTree());
        randomTree.addChild(new MMTree());
        randomTree.addChild(new MMTree());

        randomTree.children.get(0).addChild(new MMTree((int)(Math.random()*17)));
        randomTree.children.get(0).addChild(new MMTree((int)(Math.random()*17)));

        randomTree.children.get(1).addChild(new MMTree((int)(Math.random()*17)));
        randomTree.children.get(1).addChild(new MMTree((int)(Math.random()*17)));

        randomTree.children.get(2).addChild(new MMTree((int)(Math.random()*17)));
        randomTree.children.get(2).addChild(new MMTree((int)(Math.random()*17)));

        randomTree.children.get(3).addChild(new MMTree((int)(Math.random()*17)));
        randomTree.children.get(3).addChild(new MMTree((int)(Math.random()*17)));




        return randomTree;
    }






    public boolean hasNext()
    {
        return next != null;
    }



    public static void main(String args[])
    {

        /*
        MMTree self = new MMTree();

        self.addChild(new MMTree());
        self.addChild(new MMTree());
        self.addChild(new MMTree());


        self.children.get(0).addChild(new MMTree());
        self.children.get(0).addChild(new MMTree());
        self.children.get(0).addChild(new MMTree());


        self.children.get(0).children.get(0).addChild(new MMTree(2));
        self.children.get(0).children.get(0).addChild(new MMTree(0));
        self.children.get(0).children.get(0).addChild(new MMTree(5));


        self.children.get(0).children.get(1).addChild(new MMTree(9));
        self.children.get(0).children.get(1).addChild(new MMTree(6));

        self.children.get(0).children.get(2).addChild(new MMTree(4));
        self.children.get(0).children.get(2).addChild(new MMTree(1));




        self.children.get(1).addChild(new MMTree());
        self.children.get(1).addChild(new MMTree());


        self.children.get(1).children.get(0).addChild(new MMTree(7));
        self.children.get(1).children.get(0).addChild(new MMTree(8));

        self.children.get(1).children.get(1).addChild(new MMTree(9));
        self.children.get(1).children.get(1).addChild(new MMTree(5));
        self.children.get(1).children.get(1).addChild(new MMTree(2));




        self.children.get(2).addChild(new MMTree());
        self.children.get(2).addChild(new MMTree());
        self.children.get(2).addChild(new MMTree());


        self.children.get(2).children.get(0).addChild(new MMTree(4));
        self.children.get(2).children.get(0).addChild(new MMTree(3));
        self.children.get(2).children.get(0).addChild(new MMTree(1));


        self.children.get(2).children.get(1).addChild(new MMTree(7));
        self.children.get(2).children.get(1).addChild(new MMTree(6));

        self.children.get(2).children.get(2).addChild(new MMTree(1));
        self.children.get(2).children.get(2).addChild(new MMTree(0));

         */
        
        
        //System.out.println("\n\nPrint:\n");
        //inOrderPrint(self);
       //postOrderPrint(self);
       //preOrderPrint(self);
       //self.levelOrderPrint();
       //self.generateRandomTree();

        /*
        MMTree randomTree = new MMTree();
        randomTree.generateRandomTree();
        randomTree.levelOrderPrint();
        System.out.println();
        minimax(randomTree);
        randomTree.levelOrderPrint();
*/
        //minimax(self);
        //minimaxForLevel(self, 0, 3);
        //self.levelOrderPrint();

        //mini

        MMTree randomTree = generateRandomNumbersTree();
        randomTree.levelOrderPrint();
        minimax(randomTree);
        System.out.println();
        randomTree.levelOrderPrint();
    }


    
}
