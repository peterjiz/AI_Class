//
//  ArrayStack.java
//  MMTree
//
//  Created by Peter El Jiz & Kevin El-Hage on 2012-10-19.
//  Copyright (c) 2012 Peter El Jiz & Kevin El-Hage. All rights reserved.
//

public class ArrayStack
{
    private static final int DEFAULT_CAPACITY=1000;
    private int count;
    private Object[] array;

    public ArrayStack(int capacity)
    {
        array = new Object[capacity];
        count = 0;
    }

    public ArrayStack()
    {
        this(DEFAULT_CAPACITY);
    }

    public void push(Object obj)
    {
        if (this.count >= array.length)
        {
            this.enlarge();
            array[count] = obj;
            count++;
        }
        else
        {
            array[count]=obj;
            count++;

        }

    }

    public Object pop()
    {
        if (this.empty())
        {
            System.out.println("Stack is Empty");
            return null;
        }
        else
        {
            Object temp = array[--count];
            array[count]=null;
            return temp;
        }

    }

    public Object peek()
    {
        if (this.empty())
        {
            System.out.println("Stack is Empty");
            //throw new EmptyStackException()
            return null;
        }
        else
        {
            return array[count - 1];
        }

    }

    private void enlarge() // This is a private helper method which is called, once the arraystack is full
    {
        Object[] temp_array = new Object[(array.length)*2];

        if (count > 0)
        {
        for (int i=0; i < this.count; i++)
        {
            temp_array[i] = array[i];
        }

        array = temp_array;

        }
        else
        {
            array = temp_array;
        }

    }

    public boolean empty()
    {
        return (this.count==0);
    }

    public int getCount()
    {
        return this.count;
    }


}

